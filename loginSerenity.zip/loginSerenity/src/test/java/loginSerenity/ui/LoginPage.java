package loginSerenity.ui;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://studio.cucumber.io/users/sign_in")
public class LoginPage extends PageObject {
}
